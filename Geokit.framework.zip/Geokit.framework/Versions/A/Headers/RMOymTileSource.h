//
//  RMOymTileSource.h
//  geokit
//
//  Created by onyourmap on 13/07/15.
//  Copyright (c) 2015 OnYourMap. All rights reserved.
//

#ifndef geokit_RMOymTileSource_h
#define geokit_RMOymTileSource_h

#import "RMTile.h"
#import "RMAbstractWebMapSource.h"
#import "RMTileSource.h"

/**
 * OnYourMap Tile for mapbox sdk
 */
@interface RMOymTileSource : RMAbstractWebMapSource
/// Application Identifier when using OnYourMap Web Services
@property (nonatomic,strong) NSString* oym_key;
/// Tile format for the map
@property (nonatomic,strong) NSString* oym_tile_format;
/// Application key when using OnYourMap Web Services
@property (nonatomic,strong) NSString* oym_referer;
/// The url of OnYourMap Web Services
@property (nonatomic,strong) NSString* oym_url;

/**
 * Init the OnYourMap tiles provider.
 * @param url OnYourMap WebService Url
 * @param tile_format type of maps to be displayed
 * @param key application key
 * @param referer application Identifier
 * @param tileSizePixels tile size in pixels
 */
-(id)initWithUrl:(NSString*)url tile_format:(NSString*)tile_format key:(NSString*)key referer:(NSString*)referer andSize:(int)tileSizePixels;
/**
 * Return an OnYourMap tile url
 * @param tile RMTile object
 */
- (NSURL *)URLForTile:(RMTile)tile;

/**
 * Return the tile size, in pixels
 */
-(int)getTileSizePixels;

@end

#endif
