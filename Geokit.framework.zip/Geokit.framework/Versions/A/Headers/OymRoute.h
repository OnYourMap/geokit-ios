//
//  OymRoute.h
//  geokit
//
//  Created by onyourmap on 28/07/15.
//  Copyright (c) 2015 OnYourMap. All rights reserved.
//

#ifndef mapboxtest_OymRoute_h
#define mapboxtest_OymRoute_h

@import CoreLocation;
#import "RMFoundation.h"

static int const TM_PEDESTRIAN = 0;
static int const TM_FASTEST_CAR = 1;
static int const TM_PUBLIC_TRANSPORTATION = 2;
static NSString* const UNIT_KM = @"KM";
static NSString* const UNIT_MILES = @"MI";

/**
 * A Route request.
 */
@interface RouteRequest : NSObject

/// The route start coordinate in WGS84 coordinates
@property CLLocationCoordinate2D start;
/// The end start coordinate in WGS84 coordinates
@property CLLocationCoordinate2D end;
// Array of route vias in WGS84 coordinates
@property (nonatomic,strong) NSMutableArray* vias;
/// The transport mode: TM_PEDESTRIAN or TM_FASTEST_CAR
@property int transportMode;
/// The distance unit: UNIT_KM or UNIT_MILES
@property (nonatomic,strong) NSString* distanceUnit;

-(id)init;
-(NSData*)jsonify;

@end

/**
 * A Route response.
 */
@interface RouteResponse : NSObject

/// A unique identifier for this route
@property (nonatomic,strong) NSString* routeKey;
/// The distance unit: UNIT_KM or UNIT_MILES
@property (nonatomic,strong) NSString* distanceUnit;
/// The total length of the route, depending on distanceUnit
@property float length;
/// The total time of the route, in minutes
@property float time;
/// A list of route instructions, for navigation
@property (nonatomic,strong) NSArray* instructions;
/// A list of route sections, for navigation
@property (nonatomic,strong) NSArray* sections;
/// A list of route vias, for navigation
@property (nonatomic,strong) NSArray* vias;
/// The bounds of the route
@property RMSphericalTrapezium bounds;
/// The list of points for the route
@property (nonatomic,strong) NSArray* positions;
/// A list of bitmask for each points in positions list
@property (nonatomic,strong) NSArray* levels;
    
-(id)init;
+(RouteResponse*) RouteResponseFromJSON:(NSData*)jsondata;

@end

/**
 * A Route instruction.
 */
@interface RouteInstruction : NSObject

/// The maneuver index
@property int ID;
/// The length of the maneuver
@property float length;
/// The time in minutes of the maneuver
@property float time;
/// The vertex index inside Route.positions list
@property int vertexIndex;
/// The WGS84 coordinate of the maneuver
@property CLLocationCoordinate2D position;
/// The attributes of the maneuver. See render() method to automatically decode attributes into a human readable format
@property NSDictionary* attributes;


@end

/**
 * A Route section.
 */
@interface RouteSection : NSObject
/// The type of section
@property (nonatomic,strong) NSString* type;
/// The start vertex of the section in the Route.positions list
@property int startVertex;
/// The end vertex of the section in the Route.positions list
@property int endVertex;
/// The start instruction in the Route.instructions list
@property int startInstruction;
/// The end instruction in the Route.instructions list
@property int endInstruction;
/// Some additional info about the type of section
@property (nonatomic,strong) NSString* trunkCode;

@end


/**
 * A Route via.
 */
@interface RouteVia : NSObject

/// The vertex index inside Route.positions list
@property int vertexIndex;
/// The WGS84 coordinate of the via
@property CLLocationCoordinate2D position;

@end

/**
 * Utility functions for routing
 */
@interface RouteUtilities : NSObject

/** 
 * Create a human readable instruction<br>
 * Instruction can be translated/modified by editing the ressource oym-route.strings in Geokit.bundle
 * @param instruction instruction returned by the route request
 * @return string describing the instruction in readable language
 */
+(NSString*)renderInstruction:(RouteInstruction*)instruction;
+(NSString*)decodeHeading2:(NSString*)manHeading withBundle:(NSBundle*)bundle;
+(NSString*)decodeRoad:(NSString*) manRd with:(NSString*) manRdnr;
+(NSString*)decodeBranch:(NSString*) manBranch;
+(NSString*)decodeTransportType2:(NSString*)ptType withBundle:(NSBundle*)bundle;
+(NSString*)renderTime2:(NSString*)time withBundle:(NSBundle*)bundle;
+(NSString*)rebuild:(NSString*)stringTemplate with:(NSArray*)args;
/**
 * Tells if a point at with given level value should be displayed a given zoom level.
 *
 * @param displayLevelValue the displayLevelValue as returned in the route request
 * @param zoomLevel zoom level where the point should be displqyed or not
 * @return true if the point should be displayed at this zoom level
 */
+(bool)checkDisplayLevel:(int)displayLevelValue forZoomeLevel:(int)zoomLevel;

@end
#endif
