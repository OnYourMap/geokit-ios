//
//  OymPlace.h
//  geokit
//
//  Created by onyourmap on 22/07/15.
//  Copyright (c) 2015 OnYourMap. All rights reserved.
//

#ifndef mapboxtest_OymPlace_h
#define mapboxtest_OymPlace_h

@import CoreLocation;

/**
 * A Geometry represents a place's location and may also contains some additional place geometry.
 */
@interface PlaceGeometry : NSObject

 /// The location in WGS84 coordinates
@property CLLocationCoordinate2D location;
 /// The type of location
@property int type;
 /// Some additional geometry for a place, like the complete street geometry of the external polygon of a city
@property (nonatomic,strong) NSMutableArray* raw;

-(id)init;
-(NSString*)toString;

@end

/**
 * A Place Search request.
 */
@interface PlaceSearchRequest : NSObject

 /// The maximum number of places
 @property int maxResponses;
 /// The iso country code in 2 letters
 @property (nonatomic,strong) NSString* country;
 /// The city
 @property (nonatomic,strong) NSString* locality;
 /// the state or county
 @property (nonatomic,strong) NSString* adminArea;
 /// The postal code
 @property (nonatomic,strong) NSString* postcode;
 /// The address: full or just street part
 @property (nonatomic,strong) NSString* address;
 /// The output language
 @property (nonatomic,strong) NSString* lang;
 /// Places inside the viewport will be better ranked
 @property (nonatomic,strong) NSString* viewport;
 /// Places with provided favorite country will be better ranked
 @property (nonatomic,strong) NSString* favoriteCountry;

-(id)init;
-(NSData*) jsonify;
-(NSString*) toString;

@end

/**
 * Response to a place search request.
 */
@interface PlaceSearchResponse : NSObject
 /// The response time in milliseconds
@property int time;
 /// The number of places found
@property int totalHits;
 /// The response status
@property (nonatomic,strong) NSString* status;
 /// The places found, an array of OymPlace
@property NSArray* places;

-(id)init;
-(NSString*) toString;
+(PlaceSearchResponse*) PlaceSearchResponseFromJSON:(NSData*)jsondata;

@end

/**
 * A Place Nearest request.
 */
@interface PlaceNearestRequest : NSObject

/// The maximum number of places
@property int maxResponses;
 /// The location in WGS84 coordinates
@property CLLocationCoordinate2D location;
 /// The search radius in meters
@property int radius;
 /// The output language
@property (nonatomic,strong) NSString* lang;

-(id)init;
-(NSString*) toString;
-(NSData*) jsonify;

@end

/**
 * Response to a place nearest request.
 */
@interface PlaceNearestResponse : NSObject

/// The response time in milliseconds
@property int time;
 /// The number of places found
@property int totalHits;
 /// The response status
@property NSString* status;
 /// The nearest places, an array of OymPlace
@property NSArray* places;
 
-(id)init;
-(NSString*)toString;
+(PlaceNearestResponse*) PlaceNearestResponseFromJSON:(NSData*)jsondata;

@end

/**
 * A Place object.<br>
 * A list of place objects is returned by nearest and search requests, inside PlaceNearestResponse and PlaceSearchResponse <br>
 */
@interface OymPlace : NSObject

@property (nonatomic,strong) NSString* placeId;
 /// The representation of the place as one String. For example the full address.
@property (nonatomic,strong) NSString* description;
 /// A list of key/value pairs for this place. Actually used for POIs
@property (nonatomic,strong) NSDictionary* properties;
 /// The dataset can be "ADDR" or "POI"
@property (nonatomic,strong) NSString* dataset;
 /// The type of place. Can be "C" for a city, "0" for a street, or a POI type
@property (nonatomic,strong) NSString* type;
 /// The administrative levels of the address
@property (nonatomic,strong) NSDictionary* components;
 /// The geometry of the place ( PlaceGeometry object )
@property (nonatomic,strong) PlaceGeometry* geometry;

-(id)init;
-(NSString*)toString;


@end

#endif
