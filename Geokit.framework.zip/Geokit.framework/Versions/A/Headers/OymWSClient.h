//
//  OymWSClient.h
//  geokit
//
//  Created by onyourmap on 22/07/15.
//  Copyright (c) 2015 OnYourMap. All rights reserved.
//

#ifndef mapboxtest_OymWSClient_h
#define mapboxtest_OymWSClient_h
#import "OymPlace.h"
#import "OymRoute.h"

/**
 * OnYourMap GIS Web Services Client. <br>
 * Features: <br>
 *  - Geocoding (address lookup) <br>
 *  - Reverse geocoding (get address from coordinate) <br>
 *  - Routing (get directions between 2 locations) <br><br>
 *  Before starting using this client, you must have first contacted OnYourMap support in order to get credentials for accessing its Web Services.
 *  Three parameters are mandatory: <br>
 *  - webServiceUrl: The url of OnYourMap Web Services <br>
 *  - appReferer: Your application Identifier when using OnYourMap Web Services <br>
 *  - appKey: Your application key when using OnYourMap Web Services <br>
 *
 */
@interface OymWSClient : NSObject

/// The url of OnYourMap Web Services
@property (nonatomic,strong) NSString* oym_url;
/// Your application Identifier when using OnYourMap Web Services
@property (nonatomic,strong) NSString* oym_referer;
/// Your application key when using OnYourMap Web Services
@property (nonatomic,strong) NSString* oym_key;

/**
* The client entry point.
* @param url OnYourMap WebService Url
* @param key application key
* @param referer application Identifier
*/
-(id)initWithUrl:(NSString*)url key:(NSString*)key andReferer:(NSString*)referer;

/**
 * Get nearest address from a WGS84 coordinate.
 * If a callback object is provided, then the method will be executed asynchronously. If callback is null, then the method will be executed synchronously.
 * @param request PlaceNearestRequest object
 * @param callback (void(^)(PlaceNearestResponse*)) block
 */
-(PlaceNearestResponse*) nearest:(PlaceNearestRequest*) request andCall:(void(^)(PlaceNearestResponse*))callback;

/**
 * Get directions between 2 WGS84 coordinates.
 * If a callback object is provided, then the method will be executed asynchronously. If callback is null, then the method will be executed synchronously.
 * @param request RouteRequest object
 * @param callback (void(^)(RouteResponse*)) block
 */
-(RouteResponse*) directions:(RouteRequest*)request andCall:(void(^)(RouteResponse*))callback;

/**
 * Search for an address and get its WGS84 coordinate. <br>
 * If a callback object is provided, then the method will be executed asynchronously. If callback is null, then the method will be executed synchronously.
 * @param request PlaceSearchRequest object
 * @param callback (void(^)(PlaceSearchResponse*)) block
 */
-(PlaceSearchResponse*) search:(PlaceSearchRequest*) request andCall:(void(^)(PlaceSearchResponse*))callback;

@end

#endif
